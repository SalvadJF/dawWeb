function abrirNav() {
    document.getElementById("navegadorLateral").style.width = "250px";
  }
  
function cerrarNav() {
    document.getElementById("navegadorLateral").style.width = "0";
  }